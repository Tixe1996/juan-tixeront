# -*- coding: utf-8 -*-
"""
Created on Mon Jun  9 19:29:33 2025

@author: jeant
"""


# Ma327_BE_lib.py
import numpy as np
from skimage.io import imread
from skimage.util import img_as_float
import cv2
import matplotlib.pyplot as plt

# Paramètres physiques
g = 9.81 # gravité (m/s²)
L = 1.0 # longueur du pendule (m)
m=1
theta0 = np.radians(45) # angle initial en radians
omega0 = 0.0 # vitesse angulaire initiale
T = 10 # durée de simulation (s)
dt = 0.01 # pas de temps
N = int(T / dt) # nombre de pas
k = 0.5 #valeur approximative car on ne nous la donne pas dans l'énoncé, k=0.5 représente un amortissement modéré




# %%


#PARTIE 1 QUESTION 5.2 RK2 SANS FROTTEMENTS

def f_theta(omega): return omega
def f_omega(theta): return - (g / L) * np.sin(theta)

# %%

#PARTIE 1 QUESTION 5.2 RK2 SANS FROTTEMENTS

def ff_omega(theta,omega): return -(k/m) * omega - (g / L) * np.sin(theta)

#%% 5.5.3  SANS FROTTEMENTS

def f2_omega(theta, L):
    return - (g / L) * np.sin(theta)

def simulate(theta0_deg, L):
    theta0 = np.radians(theta0_deg)
    omega0 = 0.0
    

    theta = np.zeros(N)
    omega = np.zeros(N)
    theta[0] = theta0
    omega[0] = omega0

    for i in range(N - 1):
        k1_theta = dt * f_theta(omega[i])
        k1_omega = dt * f2_omega(theta[i], L)

        k2_theta = dt * f_theta(omega[i] + 0.5 * k1_omega)
        k2_omega = dt * f2_omega(theta[i] + 0.5 * k1_theta, L)

        k3_theta = dt * f_theta(omega[i] + 0.5 * k2_omega)
        k3_omega = dt * f2_omega(theta[i] + 0.5 * k2_theta, L)

        k4_theta = dt * f_theta(omega[i] + k3_omega)
        k4_omega = dt * f2_omega(theta[i] + k3_theta, L)

        theta[i+1] = theta[i] + (k1_theta + 2*k2_theta + 2*k3_theta + k4_theta)/6
        omega[i+1] = omega[i] + (k1_omega + 2*k2_omega + 2*k3_omega + k4_omega)/6

    # Energies et positions
    x = L * np.sin(theta)
    y = -L * np.cos(theta)
    v = L * omega
    Ec = 0.5 * m * v**2
    Ep = m * g * L * (1 - np.cos(theta))
    Em = Ec + Ep

    return theta, Ec, Ep, Em, x, y
    
#%% 5.5.3  AVEC FROTTEMENTS

# === Simulation RK4 ===
def simulate_pendulum(theta0_deg, L):
    theta0 = np.radians(theta0_deg)
    omega0 = 0.0

    theta = np.zeros(N)
    omega = np.zeros(N)
    theta[0] = theta0
    omega[0] = omega0

    for i in range(N - 1):
        k1_theta = dt * f_theta(omega[i])
        k1_omega = dt * ff_omega(theta[i], L)

        k2_theta = dt * f_theta(omega[i] + 0.5 * k1_omega)
        k2_omega = dt * ff_omega(theta[i] + 0.5 * k1_theta, L)

        k3_theta = dt * f_theta(omega[i] + 0.5 * k2_omega)
        k3_omega = dt * ff_omega(theta[i] + 0.5 * k2_theta, L)

        k4_theta = dt * f_theta(omega[i] + k3_omega)
        k4_omega = dt * ff_omega(theta[i] + k3_theta, L)

        theta[i+1] = theta[i] + (k1_theta + 2*k2_theta + 2*k3_theta + k4_theta)/6
        omega[i+1] = omega[i] + (k1_omega + 2*k2_omega + 2*k3_omega + k4_omega)/6

    # Energies et positions
    x = L * np.sin(theta)
    y = -L * np.cos(theta)
    v = L * omega
    Ec = 0.5 * m * v**2
    Ep = m * g * L * (1 - np.cos(theta))
    Em = Ec + Ep

    return theta, Ec, Ep, Em, x, y


#%% Conditions de Neumann PARTIE 6 :  4.a 
def completion(U):
    M, N = U.shape
    U_c = np.zeros((M+2, N+2))
    U_c[1:-1, 1:-1] = U
    U_c[0, 1:-1] = U[0, :]
    U_c[-1, 1:-1] = U[-1, :]
    U_c[1:-1, 0] = U[:, 0]
    U_c[1:-1, -1] = U[:, -1]
    U_c[0, 0] = U[0, 0]
    U_c[0, -1] = U[0, -1]
    U_c[-1, 0] = U[-1, 0]
    U_c[-1, -1] = U[-1, -1]
    return U_c

#%% Outils pour gradient et laplacien  6.4.b
def Dmat(n):
    D = np.zeros((n, n+2))
    for i in range(n):
        D[i, i] = 1
        D[i, i+1] = -2
        D[i, i+2] = 1
    return D

#%% RKimage(f,U0,t0,h,nbiter)  6.4.c

def heat_equation_rhs(t, U, D1, D2):
    U_tilde = completion(U)
    term1 = D1 @ U_tilde[:, 1:-1]
    term2 = U_tilde[1:-1, :] @ D2.T
    return term1 + term2

def RK4_step(f, t, U, h, *args):
    k1 = f(t, U, *args)
    k2 = f(t + h/2, U + h/2 * k1, *args)
    k3 = f(t + h/2, U + h/2 * k2, *args)
    k4 = f(t + h, U + h * k3, *args)
    return U + h/6 * (k1 + 2*k2 + 2*k3 + k4)

def RKimage(f, U0, t0, h, nbiter, *args):
    U = U0.copy()
    t = t0
    result = [U.copy()]
    for _ in range(nbiter):
        U = RK4_step(f, t, U, h, *args)
        t += h
        result.append(U.copy())
    return result

#%% 7.1

def compute_gradient_norm(U):
    """Calcule la norme du gradient en chaque point"""
    U_tilde = completion(U)
    dx = (U_tilde[1:-1, 2:] - U_tilde[1:-1, :-2]) / 2  # dérivée en x
    dy = (U_tilde[2:, 1:-1] - U_tilde[:-2, 1:-1]) / 2  # dérivée en y
    return np.sqrt(dx**2 + dy**2)


def RKimage_normgrad(f, U0, t0, h, nbiter):
    """
    Résout ∂u/∂t = ||∇u||_2 avec conditions de Neumann
    Args:
        f: fonction inutilisée (pour compatibilité)
        U0: image initiale (M x N x C)
        t0: temps initial (ignoré)
        h: pas de temps
        nbiter: nombre d'itérations
    Returns:
        Image évoluée
    """
    M, N, C = U0.shape
    U = U0.copy()
    
    for _ in range(nbiter):
        U_new = U.copy()
        for c in range(C):
            grad_norm = compute_gradient_norm(U[:, :, c])
            U_new[1:-1, 1:-1, c] += h * grad_norm
        U = np.clip(U_new, 0, 1)
    return U

#%% 7.2


def compute_laplacian_norm(U):
    """Calcule la norme du laplacien en chaque point"""
    U_tilde = completion(U)
    laplacian = (U_tilde[1:-1, 2:] + U_tilde[1:-1, :-2] +
                 U_tilde[2:, 1:-1] + U_tilde[:-2, 1:-1] - 
                 4 * U_tilde[1:-1, 1:-1])
    return np.abs(laplacian)

def RKimage_normlaplace(f, U0, t0, h, nbiter):
    """
    Résout ∂u/∂t = sqrt((∂²u/∂x²)² + (∂²u/∂y²)²) avec conditions de Neumann
    """
    M, N, C = U0.shape
    U = U0.copy()
    
    for _ in range(nbiter):
        U_new = U.copy()
        for c in range(C):
            laplace_norm = compute_laplacian_norm(U[:, :, c])
            U_new[1:-1, 1:-1, c] += h * laplace_norm
        U = np.clip(U_new, 0, 1)
    return U

#%% 7.3

def RKimage_normgradconstant(f, U0, t0, h, nbiter):
    M, N, C = U0.shape
    U = U0.copy()
    
    # Pré-calcul du gradient initial tronqué
    grad_norms = []
    for c in range(C):
        grad = compute_gradient_norm(U0[:, :, c])
        grad_norms.append(grad[1:-1, 1:-1])  # Ajustement ici

    for _ in range(nbiter):
        U_new = U.copy()
        for c in range(C):
            U_new[1:-1, 1:-1, c] += h * grad_norms[c]
        U = np.clip(U_new, 0, 1)
    return U

        
def RKimage_diffusion(U0, h, nbiter, mode='grad'):
    if mode == 'grad':
        return RKimage_normgrad(None, U0, 0, h, nbiter)
    elif mode == 'laplace':
        return RKimage_normlaplace(None, U0, 0, h, nbiter)
    elif mode == 'grad_constant':
        return RKimage_normgradconstant(None, U0, 0, h, nbiter)
    else:
        raise ValueError(f"Mode '{mode}' non reconnu.")  
        
#%% 7.3 BONUS       
        
# ==== Application de l'effet Schrödinger ====
def RKimage_schrodinger_effect(U0, h, nbiter):
    M, N, C = U0.shape
    U = U0.copy().astype(np.complex128)

    for _ in range(nbiter):
        U_new = U.copy()
        for c in range(C):
            U_c = U[:, :, c]
            U_tilde = completion(U_c)
            laplacian = (U_tilde[1:-1, 2:] + U_tilde[1:-1, :-2] +
                         U_tilde[2:, 1:-1] + U_tilde[:-2, 1:-1] -
                         4 * U_tilde[1:-1, 1:-1])
            nonlinear_term = np.abs(U_c)**2 * U_c
            U_new[:, :, c] += h * (1j * laplacian - 1j * nonlinear_term)
        U = U_new

    return np.clip(np.abs(U.real), 0, 1)

#%% Fonctions anisotrope
def compute_grad_norm_squared(U):
    U_c = completion(U)
    dx = (U_c[1:-1, 2:] - U_c[1:-1, :-2]) / 2
    dy = (U_c[2:, 1:-1] - U_c[:-2, 1:-1]) / 2
    return dx**2 + dy**2

def RKimage_anisotrope(U0, dt, nbiter, lamb=0.1, mode='exp'):
    M, N, C = U0.shape
    h = 1.0
    U = U0.copy()


    for _ in range(nbiter):
        U_new = np.zeros_like(U)
        for c in range(C):
            u = U[:, :, c]
            u_c = completion(u)
            s = compute_grad_norm_squared(u)
            c_val = c_function(s, lamb, mode)
            c_c = completion(c_val)

            Ax = (1 / (2 * h**2)) * (
                (c_c[1:-1, 1:-1] + c_c[:-2, 1:-1]) * u_c[:-2, 1:-1] +
                (c_c[1:-1, 1:-1] + c_c[2:, 1:-1]) * u_c[2:, 1:-1] -
                (c_c[:-2, 1:-1] + 2*c_c[1:-1, 1:-1] + c_c[2:, 1:-1]) * u_c[1:-1, 1:-1]
            )

            Ay = (1 / (2 * h**2)) * (
                (c_c[1:-1, 1:-1] + c_c[1:-1, :-2]) * u_c[1:-1, :-2] +
                (c_c[1:-1, 1:-1] + c_c[1:-1, 2:]) * u_c[1:-1, 2:] -
                (c_c[1:-1, :-2] + 2*c_c[1:-1, 1:-1] + c_c[1:-1, 2:]) * u_c[1:-1, 1:-1]
            )

            U_new[:, :, c] = u + dt * (Ax + Ay)

        # Clip entre 0 et 1 pour éviter des débordements
        U = np.clip(U_new, 0, 1)

    return U

#%% Fonction de conduction
def c_function(s, lamb=0.1, mode='exp'):
    if mode == 'exp':
        return np.exp(-s**2 / lamb**2)
    else:
        return 1 / (1 + (s**2 / lamb**2))


#%% Conversion OpenCV
def convert_for_cv(img):
    return (np.clip(img * 255, 0, 255)).astype(np.uint8)[..., ::-1]