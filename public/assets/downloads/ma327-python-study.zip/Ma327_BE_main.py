# -*- coding: utf-8 -*-
"""
Created on Mon Jun  9 19:40:27 2025

@author: jeant
"""

import numpy as np
import matplotlib.pyplot as plt
from skimage.io import imread
from skimage.util import img_as_float
from Ma327_BE_lib import *

def convert_rgb_to_bgr(image_float):
    """Convertit une image RGB (float dans [0,1]) en BGR (uint8 dans [0,255]) pour OpenCV"""
    image_uint8 = (np.clip(image_float * 255, 0, 255)).astype(np.uint8)
    return cv2.cvtColor(image_uint8, cv2.COLOR_RGB2BGR)




# %%PARTIE 1 QUESTION 5.2 RK2  SANS FROTEMENT 
# Initialisation des tableaux

t = np.linspace(0, T, N)
theta_rk2 = np.zeros(N)
omega_rk2 = np.zeros(N)


# Conditions initiales
theta_rk2[0] = theta0
omega_rk2[0] = omega0


# Méthode RK2
for i in range(N - 1):
    k1_theta = dt * f_theta(omega_rk2[i])
    k1_omega = dt * f_omega(theta_rk2[i])

    k2_theta = dt * f_theta(omega_rk2[i] + 0.5 * k1_omega)
    k2_omega = dt * f_omega(theta_rk2[i] + 0.5 * k1_theta)

    theta_rk2[i+1] = theta_rk2[i] + k2_theta
    omega_rk2[i+1] = omega_rk2[i] + k2_omega

# Coordonnées cartésiennes
x = L * np.sin(theta_rk2)
y = -L * np.cos(theta_rk2)

# Énergies
v = L * omega_rk2
Ec = 0.5 *m* v**2 # Énergie cinétique (m = L = 1)
Ep = m*g * L * (1 - np.cos(theta_rk2)) # Énergie potentielle
Em = Ec + Ep # Énergie mécanique totale

# === Affichages ===
plt.figure(figsize=(12, 10))

# 1. θ(t)
plt.subplot(2, 2, 1)
plt.plot(t, np.degrees(theta_rk2), label='RK2')
plt.xlabel("Temps (s)")
plt.ylabel("Angle θ (degrés)")
plt.title("Évolution de θ(t)")
plt.grid()
plt.legend()

# 2. Trajectoire
plt.subplot(2, 2, 2)
plt.plot(x, y)
plt.xlabel("x (m)")
plt.ylabel("y (m)")
plt.title("Trajectoire du pendule")
plt.axis("equal")
plt.grid()

# 3. Énergies
plt.subplot(2, 1, 2)
plt.plot(t, Ec, label="Énergie cinétique")
plt.plot(t, Ep, label="Énergie potentielle")
plt.plot(t, Em, label="Énergie mécanique")
plt.xlabel("Temps (s)")
plt.ylabel("Énergie (J)")
plt.title("Évolution des énergies")
plt.grid()
plt.legend()

plt.tight_layout()
plt.show()


#%% PARTIE 1 QUESTION 5.5.2 RK2 AVEC FROTEMENT 
# Initialisation des tableaux
t = np.linspace(0, T, N)
theta_rk2 = np.zeros(N)
omega_rk2 = np.zeros(N)


# Conditions initiales
theta_rk2[0] = theta0
omega_rk2[0] = omega0

# Méthode RK2
for i in range(N - 1):
    k1_theta = dt * f_theta(omega_rk2[i])
    k1_omega = dt * ff_omega(theta_rk2[i] , omega_rk2[i])

    k2_theta = dt * f_theta(omega_rk2[i] + 0.5 * k1_omega)
    k2_omega = dt * ff_omega(theta_rk2[i] + 0.5 * k1_theta, omega_rk2[i] + 0.5 * k1_omega)

    theta_rk2[i+1] = theta_rk2[i] + k2_theta
    omega_rk2[i+1] = omega_rk2[i] + k2_omega

# Coordonnées cartésiennes
x = L * np.sin(theta_rk2)
y = -L * np.cos(theta_rk2)

# Énergies
v = L * omega_rk2
Ec = 0.5 *m* v**2 # Énergie cinétique (m = L = 1)
Ep = m*g * L * (1 - np.cos(theta_rk2)) # Énergie potentielle
Em = Ec + Ep # Énergie mécanique totale

# === Affichages ===
plt.figure(figsize=(12, 10))

# 1. θ(t)
plt.subplot(2, 2, 1)
plt.plot(t, np.degrees(theta_rk2), label='RK2')
plt.xlabel("Temps (s)")
plt.ylabel("Angle θ (degrés)")
plt.title("Évolution de θ(t)")
plt.grid()
plt.legend()

# 2. Trajectoire
plt.subplot(2, 2, 2)
plt.plot(x, y)
plt.xlabel("x (m)")
plt.ylabel("y (m)")
plt.title("Trajectoire du pendule")
plt.axis("equal")
plt.grid()

# 3. Énergies
plt.subplot(2, 1, 2)
plt.plot(t, Ec, label="Énergie cinétique")
plt.plot(t, Ep, label="Énergie potentielle")
plt.plot(t, Em, label="Énergie mécanique")
plt.xlabel("Temps (s)")
plt.ylabel("Énergie (J)")
plt.title("Évolution des énergies")
plt.grid()
plt.legend()

plt.tight_layout()
plt.show()

# %%

#PARTIE 1 QUESTION 5.2 RK4  SANS FROTEMENT 

# Initialisation des tableaux
t = np.linspace(0, T, N)
theta_rk4 = np.zeros(N)
omega_rk4 = np.zeros(N)

# Conditions initiales
theta_rk4[0] = theta0
omega_rk4[0] = omega0

# Méthode RK4
for i in range(N - 1):
    k1_theta = dt * f_theta(omega_rk4[i])
    k1_omega = dt * f_omega(theta_rk4[i])

    k2_theta = dt * f_theta(omega_rk4[i] + 0.5 * k1_omega)
    k2_omega = dt * f_omega(theta_rk4[i] + 0.5 * k1_theta)

    k3_theta = dt * f_theta(omega_rk4[i] + 0.5 * k2_omega)
    k3_omega = dt * f_omega(theta_rk4[i] + 0.5 * k2_theta)

    k4_theta = dt * f_theta(omega_rk4[i] + k3_omega)
    k4_omega = dt * f_omega(theta_rk4[i] + k3_theta)

    theta_rk4[i+1] = theta_rk4[i] + (k1_theta + 2*k2_theta + 2*k3_theta + k4_theta)/6
    omega_rk4[i+1] = omega_rk4[i] + (k1_omega + 2*k2_omega + 2*k3_omega + k4_omega)/6

# Coordonnées cartésiennes
x = L * np.sin(theta_rk4)
y = -L * np.cos(theta_rk4)

# Énergies
v = L * omega_rk4
Ec = 0.5 *m* v**2 # Énergie cinétique (m = L = 1)
Ep = m*g * L * (1 - np.cos(theta_rk4)) # Énergie potentielle
Em = Ec + Ep # Énergie mécanique totale

# === Affichages ===
plt.figure(figsize=(12, 10))

# 1. θ(t)
plt.subplot(2, 2, 1)
plt.plot(t, np.degrees(theta_rk4), label='RK4')
plt.xlabel("Temps (s)")
plt.ylabel("Angle θ (degrés)")
plt.title("Évolution de θ(t)")
plt.grid()
plt.legend()

# 2. Trajectoire
plt.subplot(2, 2, 2)
plt.plot(x, y)
plt.xlabel("x (m)")
plt.ylabel("y (m)")
plt.title("Trajectoire du pendule")
plt.axis("equal")
plt.grid()

# 3. Énergies
plt.subplot(2, 1, 2)
plt.plot(t, Ec, label="Énergie cinétique")
plt.plot(t, Ep, label="Énergie potentielle")
plt.plot(t, Em, label="Énergie mécanique")
plt.xlabel("Temps (s)")
plt.ylabel("Énergie (J)")
plt.title("Évolution des énergies")
plt.grid()
plt.legend()

plt.tight_layout()
plt.show()

# %%

#PARTIE 1 QUESTION 5.2 RK4  AVEC FROTEMENT 

# Initialisation des tableaux
t = np.linspace(0, T, N)
theta_rk4 = np.zeros(N)
omega_rk4 = np.zeros(N)

# Conditions initiales
theta_rk4[0] = theta0
omega_rk4[0] = omega0
# Méthode RK4
for i in range(N - 1):
    k1_theta = dt * f_theta(omega_rk4[i])
    k1_omega = dt * ff_omega(theta_rk4[i], omega_rk4[i])

    k2_theta = dt * f_theta(omega_rk4[i] + 0.5 * k1_omega)
    k2_omega = dt * ff_omega(theta_rk4[i] + 0.5 * k1_theta, omega_rk4[i] + 0.5 * k1_omega)

    k3_theta = dt * f_theta(omega_rk4[i] + 0.5 * k2_omega)
    k3_omega = dt * ff_omega(theta_rk4[i] + 0.5 * k2_theta, omega_rk4[i] + 0.5 * k2_omega)

    k4_theta = dt * f_theta(omega_rk4[i] + k3_omega)
    k4_omega = dt * ff_omega(theta_rk4[i] + k3_theta, omega_rk4[i] + k3_omega)

    theta_rk4[i+1] = theta_rk4[i] + (k1_theta + 2*k2_theta + 2*k3_theta + k4_theta) / 6
    omega_rk4[i+1] = omega_rk4[i] + (k1_omega + 2*k2_omega + 2*k3_omega + k4_omega) / 6

# Coordonnées cartésiennes
x = L * np.sin(theta_rk4)
y = -L * np.cos(theta_rk4)

# Énergies
v = L * omega_rk4
Ec = 0.5 *m* v**2 # Énergie cinétique (m = L = 1)
Ep = m*g * L * (1 - np.cos(theta_rk4)) # Énergie potentielle
Em = Ec + Ep # Énergie mécanique totale

# === Affichages ===
plt.figure(figsize=(12, 10))

# 1. θ(t)
plt.subplot(2, 2, 1)
plt.plot(t, np.degrees(theta_rk4), label='RK4')
plt.xlabel("Temps (s)")
plt.ylabel("Angle θ (degrés)")
plt.title("Évolution de θ(t)")
plt.grid()
plt.legend()

# 2. Trajectoire
plt.subplot(2, 2, 2)
plt.plot(x, y)
plt.xlabel("x (m)")
plt.ylabel("y (m)")
plt.title("Trajectoire du pendule")
plt.axis("equal")
plt.grid()

# 3. Énergies
plt.subplot(2, 1, 2)
plt.plot(t, Ec, label="Énergie cinétique")
plt.plot(t, Ep, label="Énergie potentielle")
plt.plot(t, Em, label="Énergie mécanique")
plt.xlabel("Temps (s)")
plt.ylabel("Énergie (J)")
plt.title("Évolution des énergies")
plt.grid()
plt.legend()

plt.tight_layout()
plt.show()


#%% 5.5.3 SANS FROTTEMENTS

# === Paramètres fixes ===
g = 9.81
m = 1.0
T = 10
dt = 0.01
N = int(T / dt)
t = np.linspace(0, T, N)


# === Étude 1 : variation de θ₀ ===
theta0_list = [10, 45, 90]
L_fixed = 1.0

plt.figure(figsize=(15, 12))

for i, theta0 in enumerate(theta0_list):
    theta, Ec, Ep, Em, x, y = simulate(theta0, L_fixed)

    # θ(t)
    plt.subplot(3, 3, 1)
    plt.plot(t, np.degrees(theta), label=f'θ₀={theta0}°')
    plt.title("Évolution de θ(t)")
    plt.xlabel("Temps (s)")
    plt.ylabel("θ (°)")
    plt.grid()
    plt.legend()

    # Énergies
    plt.subplot(3, 3, 2)
    plt.plot(t, Ec, '--', label=f'Ec θ₀={theta0}°')
    plt.plot(t, Ep, ':', label=f'Ep θ₀={theta0}°')
    plt.plot(t, Em, label=f'Em θ₀={theta0}°')
    plt.title("Énergies vs temps (variation θ₀)")
    plt.xlabel("Temps (s)")
    plt.ylabel("Énergie (J)")
    plt.grid()
    plt.legend()

    # Trajectoire
    plt.subplot(3, 3, 3)
    plt.plot(x, y, label=f'θ₀={theta0}°')
    plt.title("Trajectoire (variation θ₀)")
    plt.xlabel("x (m)")
    plt.ylabel("y (m)")
    plt.axis("equal")
    plt.grid()
    plt.legend()

# === Étude 2 : variation de L ===
L_list = [0.5, 1.0, 2.0]
theta0_fixed = 45

for i, L in enumerate(L_list):
    theta, Ec, Ep, Em, x, y = simulate(theta0_fixed, L)

    # θ(t)
    plt.subplot(3, 3, 4)
    plt.plot(t, np.degrees(theta), label=f'L={L} m')
    plt.title("Évolution de θ(t) vs L")
    plt.xlabel("Temps (s)")
    plt.ylabel("θ (°)")
    plt.grid()
    plt.legend()

    # Énergies
    plt.subplot(3, 3, 5)
    plt.plot(t, Ec, '--', label=f'Ec L={L} m')
    plt.plot(t, Ep, ':', label=f'Ep L={L} m')
    plt.plot(t, Em, label=f'Em L={L} m')
    plt.title("Énergies vs temps (variation L)")
    plt.xlabel("Temps (s)")
    plt.ylabel("Énergie (J)")
    plt.grid()
    plt.legend()

    # Trajectoire
    plt.subplot(3, 3, 6)
    plt.plot(x, y, label=f'L={L} m')
    plt.title("Trajectoire (variation L)")
    plt.xlabel("x (m)")
    plt.ylabel("y (m)")
    plt.axis("equal")
    plt.grid()
    plt.legend()

plt.tight_layout()
plt.show()

#%% 5.5.3 AVEC FROTTEMENTS

# === Paramètres fixes ===
g = 9.81
m = 1.0
T = 10
dt = 0.01
N = int(T / dt)
t = np.linspace(0, T, N)

# Étude 1 : variation de theta0
theta0_list = [10, 45, 90]
L_fixed = 1.0

plt.figure(figsize=(14, 10))

for theta0 in theta0_list:
    theta, Ec, Ep, Em, x, y = simulate_pendulum(theta0, L_fixed)

    # θ(t)
    plt.subplot(3, 3, 1)
    plt.plot(t, np.degrees(theta), label=f'θ₀={theta0}°')
    plt.title("Évolution de θ(t)")
    plt.xlabel("Temps (s)")
    plt.ylabel("θ (degrés)")
    plt.grid()
    plt.legend()

    # Énergies
    plt.subplot(3, 3, 2)
    plt.plot(t, Ec, label=f'Ec θ₀={theta0}°')
    plt.plot(t, Ep, label=f'Ep θ₀={theta0}°')
    plt.plot(t, Em, label=f'Em θ₀={theta0}°')
    plt.title("Énergies vs temps")
    plt.xlabel("Temps (s)")
    plt.ylabel("Énergie (J)")
    plt.grid()
    plt.legend()

    # Trajectoire
    plt.subplot(3, 3, 3)
    plt.plot(x, y, label=f'θ₀={theta0}°')
    plt.title("Trajectoire")
    plt.xlabel("x (m)")
    plt.ylabel("y (m)")
    plt.axis("equal")
    plt.grid()
    plt.legend()

# Étude 2 : variation de L
L_list = [0.5, 1.0, 2.0]
theta0_fixed = 45

for L in L_list:
    theta, Ec, Ep, Em, x, y = simulate_pendulum(theta0_fixed, L)

    # θ(t)
    plt.subplot(3, 3, 4)
    plt.plot(t, np.degrees(theta), label=f'L={L} m')
    plt.title("Évolution de θ(t) vs L")
    plt.xlabel("Temps (s)")
    plt.ylabel("θ (degrés)")
    plt.grid()
    plt.legend()

    # Énergies
    plt.subplot(3, 3, 5)
    plt.plot(t, Ec, label=f'Ec L={L} m')
    plt.plot(t, Ep, label=f'Ep L={L} m')
    plt.plot(t, Em, label=f'Em L={L} m')
    plt.title("Énergies vs temps")
    plt.xlabel("Temps (s)")
    plt.ylabel("Énergie (J)")
    plt.grid()
    plt.legend()

    # Trajectoire
    plt.subplot(3, 3, 6)
    plt.plot(x, y, label=f'L={L} m')
    plt.title("Trajectoire")
    plt.xlabel("x (m)")
    plt.ylabel("y (m)")
    plt.axis("equal")
    plt.grid()
    plt.legend()

plt.tight_layout()
plt.show()



#%%  Partie 6 : Équation de la chaleur

image_bgr = cv2.imread("C:/Users/jeant/Desktop/RENDUE_Ma327/test5.jpg")
if image_bgr is None:
    raise FileNotFoundError("Image non trouvée. Vérifie le chemin.")

image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
image_rgb = image_rgb.astype(np.float32) / 255.0

M, N, C = image_rgb.shape
h = 0.1
nbiter = 100

D1 = Dmat(M)
D2 = Dmat(N)

channels_out = []
for c in range(3):
    channel = image_rgb[:, :, c]
    result = RKimage(heat_equation_rhs, channel, 0, h, nbiter, D1, D2)
    channels_out.append(result)

final_image_rgb = np.stack([channels_out[c][-1] for c in range(3)], axis=2)
final_image_bgr = convert_rgb_to_bgr(final_image_rgb)

cv2.imshow("Originale", image_bgr)
cv2.imshow("Image après diffusion (OpenCV)", final_image_bgr)
cv2.imwrite("Paysage.png", final_image_bgr)


#%% PARTIE 7 

def convert_rgb_to_bgr(image_float):
    image_uint8 = (image_float * 255).astype(np.uint8)
    return cv2.cvtColor(image_uint8, cv2.COLOR_RGB2BGR)


   
# Partie 7 : diffusion avec norme du gradient / laplacien

image = img_as_float(imread("C:/Users/jeant/Desktop/RENDUE_Ma327/fraise.jpg"))

if image.ndim != 3 or image.shape[2] != 3:
    raise ValueError("L'image doit être en couleur (3 canaux RGB)")

h = 0.01
nbiter = 200
mode = 'grad_constant'  # ou 'grad', 'laplace'

result = RKimage_diffusion(image, h, nbiter, mode=mode)

original_bgr = convert_rgb_to_bgr(image)
result_bgr = convert_rgb_to_bgr(result)

cv2.imshow("Image originale", original_bgr)
cv2.imshow(f"Image modifiée - {mode}", result_bgr)
cv2.imwrite("result.png", result_bgr)



#%% PARTIE 7 BONUS 

# ==== Conversion RGB → BGR pour OpenCV ====
def convert_rgb_to_bgr(image_float):
    image_uint8 = (np.clip(image_float, 0, 1) * 255).astype(np.uint8)
    return cv2.cvtColor(image_uint8, cv2.COLOR_RGB2BGR)

# ==== Chargement de l'image ====
image = img_as_float(imread("C:/Users/jeant/Desktop/RENDUE_Ma327/fraise.jpg"))



h = 0.01
nbiter = 160
result = RKimage_schrodinger_effect(image, h, nbiter)

    # Conversion pour affichage OpenCV
original_bgr = convert_rgb_to_bgr(image)
result_bgr = convert_rgb_to_bgr(result)

    # Affichage avec OpenCV
cv2.imshow("Image originale", original_bgr)
cv2.imshow("Effet équation de Schrödinger", result_bgr)

    # Sauvegarde
cv2.imwrite("result_schrodinger.png", result_bgr)





#%% PARTIE 8 
if __name__ == "__main__":
    path = "C:/Users/jeant/Desktop/RENDUE_Ma327/tableau1 (1).jpg"
    image = img_as_float(imread(path))

    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError("L'image doit être RGB couleur")

    dt = 0.1
    nbiter = 20
    lamb = 0.01

    print("Diffusion anisotrope (exp)...")
    result_exp = RKimage_anisotrope(image, dt, nbiter, lamb, mode='exp')

    print("Diffusion anisotrope (frac)...")
    result_frac = RKimage_anisotrope(image, dt, nbiter, lamb, mode='frac')

    # Conversion OpenCV (float [0,1] -> uint8 [0,255])
    def convert_for_cv(img):
        return (np.clip(img * 255, 0, 255)).astype(np.uint8)[..., ::-1]  # RGB -> BGR

    image_bgr = convert_for_cv(image)
    result_exp_bgr = convert_for_cv(result_exp)
    result_frac_bgr = convert_for_cv(result_frac)

    # Affichage
    cv2.imshow("Originale", image_bgr)
    cv2.imshow("Diffusion exp", result_exp_bgr)
    cv2.imshow("Diffusion frac", result_frac_bgr)

    # Sauvegarde (optionnel)
    cv2.imwrite("result_exp.jpg", result_exp_bgr)
    cv2.imwrite("result_frac.jpg", result_frac_bgr)

    print("Appuyez sur une touche pour fermer les fenêtres...")
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
