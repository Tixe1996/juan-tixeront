# MA327 numerical methods study

Original academic Python files and image assets from the June 2025 project.

- Ma327_BE_main.py: experiment sections and plotting/image display.
- Ma327_BE_lib.py: numerical routines and image operators.
- Input JPGs: photographs and reproductions used as numerical inputs.
- IMAGES1: saved experiment outputs supplied with the original project.

These scripts are an archival coursework snapshot, not an installable package.
They retain the original absolute Windows paths, which must be adapted to the
local input directory before running. Dependencies include NumPy, Matplotlib,
OpenCV and scikit-image. The portfolio compares the saved files; it does not
claim to have rerun or validated every numerical routine.

The artworks and photographs are study inputs, not original works by Juan
Tixeront. Their inclusion documents the image-processing experiments.
